﻿using System;
using System.Numerics;

namespace ToWords
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                Console.Write("Please input your numbers: ");

                BigInteger b1 = BigInteger.Parse(Console.ReadLine());

                string str = b1.ToString("N0");
                Console.WriteLine(str);
                string[] arr = str.Split(',');

                int[] number = Array.ConvertAll(arr, int.Parse);

                ToWords tw = new ToWords(number);
                Console.WriteLine("Enter Escape to exit or press anything to continue");
            } while (Console.ReadKey().Key != ConsoleKey.Escape);
        }

    }

}
