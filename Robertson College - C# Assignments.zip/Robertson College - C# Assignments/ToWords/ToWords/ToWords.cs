﻿using System;

namespace ToWords
{
    class ToWords
    {
        // index
        private string[] units = {"", "One", "Two", "Three",
                "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven",
                "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
                "Seventeen", "Eighteen", "Nineteen" };

        private string[] tens = {"", "", "Twenty", "Thirty", "Forty",
                "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

        private string[] million = { "", "Thousand", "Million", "Billion", "Trillion",
                "Quadrillion", "Quintillion", "Sextillion", "Septillion", "Octillion",
                "Nonillion", "Decillion", "Undecillion", "Duodecillion", "Tredecillion",
                "Quattuordecillion", "Quindecillion", "Sexdicillion", "Septdicillion", "Octodecillion",
                "Novemdecillion", "Vigintillion", "Centillion" };

        // String Parts for OutPuts
        private string firstPart = String.Empty;
        private string secondPart = String.Empty;
        private string thirdPart = String.Empty;

        // String parts for the first parts
        private string hundredPart;
        private string tenthPart;
        private string onePart;

        // Int holders for the first parts
        private int hundreds;
        private int tenthsValid;
        private int tenths;
        private int ones;

        public ToWords(int[] number)
        {
            // First Part of the String
            if (number[0].ToString().Length == 3)
            {
                hundreds = number[0] / 100;
                hundredPart = $"{units[hundreds]} Hundred";

                tenthsValid = (number[0] % 100);
                if (tenthsValid > 19)
                {
                    tenths = tenthsValid / 10;
                    tenthPart = $"{tens[tenths]}-";
                    ones = tenthsValid % 10;
                    onePart = $"{units[ones]}";

                    firstPart = $"{hundredPart} {tenthPart}{onePart}";
                }
                else if (tenthsValid < 20)
                {
                    tenths = tenthsValid;
                    tenthPart = $"{units[tenths]}";

                    firstPart = $"{hundredPart} {tenthPart}";
                }
            }
            else if (number[0].ToString().Length < 3)
            {
                tenthsValid = (number[0] % 100);
                if (tenthsValid > 19)
                {
                    tenths = tenthsValid / 10;
                    tenthPart = $"{tens[tenths]}-";
                    ones = tenthsValid % 10;
                    onePart = $"{units[ones]}";

                    firstPart = $"{tenthPart}{onePart}";
                }
                else if (tenthsValid < 20)
                {
                    tenths = tenthsValid;
                    tenthPart = $"{units[tenths]}";

                    firstPart = $"{tenthPart}";
                }
            }

            // Second Part of the String
            if (number.Length > 1)
            {
                if (number[1] >= 250 && number[1] <= 349)
                {
                    secondPart = " And a Quarter";
                }
                else if (number[1] >= 350 && number[1] <= 649)
                {
                    secondPart = " And a Half";
                }
                else if (number[1] >= 650 && number[1] <= 999)
                {
                    secondPart = " And Three-Quarter";
                }
            }

            // Third Part of the String
            if (number.Length > 1)
            {
                thirdPart = million[number.Length - 1];
            }
            else if (number.Length == 1)
            {
                thirdPart = million[0];
            }

            Console.WriteLine($"{firstPart}{secondPart} {thirdPart}");
        }



    }
}
