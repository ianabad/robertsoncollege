﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Shapes
{
    [Serializable()]
    public class Rectangle : Shape
    {
        public Rectangle() {}

        public double Height { get; set; }
        public double Width { get; set; }

        public override string Name
        {
            get { return "Rectangle"; }
        }
        public override double Area
        {
            get { return Height * Width; }
        }
    }
}
