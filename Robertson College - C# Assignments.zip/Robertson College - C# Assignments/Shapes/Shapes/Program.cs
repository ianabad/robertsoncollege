﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using static System.Console;

namespace Shapes
{
    class Program
    {
        static void Main(string[] args)
        {
            // create a list of Shapes to serialize
            var listOfShapes = new List<Shape>
            {
            new Circle { Colour = "Red", Radius = 2.5 },
            new Rectangle { Colour = "Blue", Height = 20.0, Width = 10.0 },
            new Circle { Colour = "Green", Radius = 8 },
            new Circle { Colour = "Purple", Radius = 12.3 },
            new Rectangle { Colour = "Blue", Height = 45.0, Width = 18.0 }
            };

            string path = @"data.xml";

            // Delete the file if it exists
            if (File.Exists(path))
            {
                File.Delete(path);
            }

            // To Serialize to XML
            var serializerXml = new XmlSerializer(typeof(List<Shape>));

            using (FileStream fs = File.Create(path))
            {
                serializerXml.Serialize(fs, listOfShapes);
            }

            WriteLine("Serialized to XML");
            WriteLine($"{File.ReadAllText(path)}\n");

            // To Deserialize
            WriteLine("Loading shapes from XML");
            using (FileStream fileXml = File.Open(path, FileMode.Open))
            {
                List<Shape> loadedShapesXml = serializerXml.Deserialize(fileXml) as List<Shape>;
                foreach (Shape item in loadedShapesXml)
                {
                    WriteLine($"{item.GetType().Name} is {item.Colour} and has an area of {item.Area}");
                }
            }

            Console.WriteLine("\nPress Anything to Exit");
            ReadKey(true);
        }
    }
}
