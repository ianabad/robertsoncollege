﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Shapes
{
    [Serializable()]
    [XmlInclude(typeof(Rectangle))]
    [XmlInclude(typeof(Circle))]
    public class Shape
    {
        public Shape() { }
        public virtual string Name { get; set; }
        public string Colour { get; set; }
        public virtual double Area { get; }
    }
}

