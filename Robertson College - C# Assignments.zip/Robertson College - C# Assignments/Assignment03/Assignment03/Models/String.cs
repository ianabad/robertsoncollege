﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Assignment03.Models
{
    public partial class String
    {
        public int StringId { get; set; }
        public string StringData { get; set; }
    }
}
