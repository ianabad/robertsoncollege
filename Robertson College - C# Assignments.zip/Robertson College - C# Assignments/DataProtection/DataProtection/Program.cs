﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using static System.Console;
using System.Security.Cryptography;
using DataProtectionLibrary;

namespace DataProtection
{
    public class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // This will get the current PROJECT directory
                string projectDirectory = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName;

                // File Path
                string path = $"{projectDirectory}\\XmlFile.xml";

                var xs = new XmlSerializer(typeof(customers));
                string key = "7A24432646294A40";

                // To load XML info to C#
                WriteLine("Customer Information: \n ------------------------------------------------------------------");

                using (FileStream fs = File.Open(path, FileMode.Open))
                {
                    customers customerinfo = xs.Deserialize(fs) as customers;
                    foreach (var customer in customerinfo.customerList)
                    {
                        string name = customer.name;
                        string protectedpassword = customer.getProtectedPassword();
                        string encryptedcc = ProtectData.EncryptString(key, customer.creditcard);
                        string unprotectedpassword = customer.password;
                        string decryptedcc = ProtectData.DecryptString(key, encryptedcc);

                        WriteLine($"Name: {name}");
                        WriteLine($"Protected Password: {protectedpassword}");
                        WriteLine($"Encrypted Credit Card: {encryptedcc}");

                        WriteLine($"\nPress ENTER to see your unprotected password. Press any key to skip.");

                        if (ReadKey(true).Key == ConsoleKey.Enter)
                        {
                            WriteLine($"Unprotected Password: {unprotectedpassword}");
                        }

                        WriteLine($"\nPress ENTER to decrypt your credit card. Press any key to skip.");
                        if (ReadKey(true).Key == ConsoleKey.Enter)
                        {
                            WriteLine($"Decryted Credit Card: {decryptedcc}");
                        }

                    }

                }

                Write("\nPress anything to exit...");
                ReadLine();

            } catch (FileNotFoundException  e)
            {
                Console.WriteLine(e.ToString());
            }

        }

    }
}
