﻿using System;
using System.Text;
using System.Text.RegularExpressions;

namespace RegEx
{
    class Program
    {
        static void Main(string[] args)
        {

            do {
                StartPrompts();
                Console.WriteLine();
            } while (Console.ReadKey(true).Key != ConsoleKey.Escape);
            
        }

        // Method to start the validation process
        static void StartValidation(string pattern, string value)
        {
            Regex re = new Regex(pattern);
            Console.WriteLine($"{value} matches {pattern}? {re.IsMatch(value)}");
        }

        // Method for the prompts
        static void StartPrompts() 
        {
            StringBuilder pattern = new StringBuilder();
            string tempinput;
            string value;
           
            Console.WriteLine( "The default regular expression checks for at least one digit." );
            Console.Write( "Enter a regular expression (or press Enter to use the default): " );

            // Conditional set to either press Enter or Enter expression
            tempinput = Console.ReadLine();                    
            if (tempinput.Length != 0 || !String.IsNullOrEmpty(tempinput) )
            {
                pattern.Append(tempinput);
            } else if (tempinput.Length == 0 || String.IsNullOrEmpty(tempinput))
            {
                pattern.Append(@"^[a-z]+$");
            }

            // Input ReadLine for the word
            Console.Write( "Enter some input: " );
            value = Console.ReadLine();
            
            // Calling validation
            StartValidation( pattern.ToString(), value );

            // Prompt to exit or continue
            Console.Write( "Press ESC to end or any key to try again." );
        }
    }
}
